self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1e05c5dde15f138679aea4c44de494e6",
    "url": "./index.html"
  },
  {
    "revision": "d3dda86cd27afbf7b748",
    "url": "./static/css/main.2dbac54d.chunk.css"
  },
  {
    "revision": "542650972b176197e8e1",
    "url": "./static/js/2.afc43eae.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.afc43eae.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d3dda86cd27afbf7b748",
    "url": "./static/js/main.e4f3bd63.chunk.js"
  },
  {
    "revision": "9d7cfb86bd01c8401f8d",
    "url": "./static/js/runtime-main.54ec1bad.js"
  },
  {
    "revision": "c8b6e083af3f94009801989c3739425e",
    "url": "./static/media/Montserrat-Medium.c8b6e083.ttf"
  },
  {
    "revision": "c641dbee1d75892e4d88bdc31560c91b",
    "url": "./static/media/Montserrat-SemiBold.c641dbee.ttf"
  }
]);