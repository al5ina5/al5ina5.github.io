'use strict'

class LikeButton extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            symbols: 'aapl,ibm,twtr,fb,tsla,dxcm,nvda',
            stockData: '123!',
            stocks: [],
            ready: false
        }
    }

    getStocks = () => {
        axios.get(`https://cloud.iexapis.com/stable/stock/market/batch?symbols=${this.state.symbols}&types=quote&range=1m&last=10&token=pk_14ab404fbb9e446e815acd51e016b071`)
            .then((response) => {
                var stocks = []
                for (var i in response.data) {
                    var temp = {
                        symbol: response.data[i].quote.symbol,
                        price: response.data[i].quote.latestPrice

                    }
                    stocks.push(temp)
                }

                this.setState({
                    stocks: stocks,
                    stockData: response.data,
                    ready: true
                })
        })
        .catch(function (error) {
            console.log(error)
        })  
    }

    componentDidMount() {
        this.getStocks()
        
        setInterval(() => {
            console.log('Updating data...')
            this.getStocks()
        }, (1000 * 60 * 10))
    }

    render() {
        return (
            <div>
                <div className="ticker">
                    {this.state.ready ? '' : <i className="fas fa-circle-notch fa-spin"></i> }
                    {this.state.stocks.map((stock, index) => (
                        <div key={index} className="stock">
                            <div className="symbol">{stock.symbol}</div>
                            <div className="price">${stock.price}</div>
                        </div>
                    ))}
                </div>
                {/* {JSON.stringify(this.state.stockData)} */}
            </div>
        )
    }
}

let domContainer = document.querySelector('#react')
ReactDOM.render(<LikeButton />, domContainer)