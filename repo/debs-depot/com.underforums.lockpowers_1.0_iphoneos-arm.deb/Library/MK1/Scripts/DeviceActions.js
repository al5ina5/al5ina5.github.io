if (MK1_ARG == 'Respring') {
	confirm(
		'Are you sure you want to respring your device?',
		'Tap OK to respring.',
		c => {
			if (c) device.respring();
		}
	);
} else if (MK1_ARG == 'Safemode') {
	confirm(
		'Are you sure you want to put your device in safemode?',
		'Tap OK to enter safemode.',
		c => {
			if (c) device.safemode();
		}
	);
} else if (MK1_ARG == 'Reboot') {
	confirm(
		'Are you sure you want to reboot your device?',
		'Tap OK to reboot.',
		c => {
			if (c) device.reboot();
		}
	);
} else if (MK1_ARG == 'Shutdown') {
	confirm(
		'Are you sure you want to shutdown your device?',
		'Tap OK to shutdown.',
		c => {
			if (c) device.shutdown();
		}
	);
}