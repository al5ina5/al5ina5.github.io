self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d3232a6fcc13264dc860dc61ff75ebde",
    "url": "./index.html"
  },
  {
    "revision": "6fc66360a4a9a0fecc15",
    "url": "./static/css/main.5dbd466c.chunk.css"
  },
  {
    "revision": "b7c46d5455410f2348d7",
    "url": "./static/js/2.cbb2ae25.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.cbb2ae25.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6fc66360a4a9a0fecc15",
    "url": "./static/js/main.959c0147.chunk.js"
  },
  {
    "revision": "e6fe1cbe3be1c41a64e1",
    "url": "./static/js/runtime-main.be1dfd25.js"
  }
]);