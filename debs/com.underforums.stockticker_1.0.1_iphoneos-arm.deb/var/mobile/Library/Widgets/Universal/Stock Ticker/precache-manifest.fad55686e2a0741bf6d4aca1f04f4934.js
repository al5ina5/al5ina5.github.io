self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b4c57cb7c5bd13d9279ff99ae2692535",
    "url": "./index.html"
  },
  {
    "revision": "42b98d3bcf001fb3948f",
    "url": "./static/css/main.e4a5a7f1.chunk.css"
  },
  {
    "revision": "b7c46d5455410f2348d7",
    "url": "./static/js/2.cbb2ae25.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.cbb2ae25.chunk.js.LICENSE.txt"
  },
  {
    "revision": "42b98d3bcf001fb3948f",
    "url": "./static/js/main.959c0147.chunk.js"
  },
  {
    "revision": "e6fe1cbe3be1c41a64e1",
    "url": "./static/js/runtime-main.be1dfd25.js"
  }
]);