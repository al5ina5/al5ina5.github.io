self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "77f7c424dc2f378249cfe94b96fbf0ea",
    "url": "./index.html"
  },
  {
    "revision": "c1c8a95f2c67e2915d15",
    "url": "./static/css/main.72af27c5.chunk.css"
  },
  {
    "revision": "37c6f2bf9071714bce60",
    "url": "./static/js/2.481c6fe2.chunk.js"
  },
  {
    "revision": "501f379103cbfcb5ff11211dd39a28a2",
    "url": "./static/js/2.481c6fe2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c1c8a95f2c67e2915d15",
    "url": "./static/js/main.f240bdb9.chunk.js"
  },
  {
    "revision": "d16bc18d9642e80c33ac",
    "url": "./static/js/runtime-main.6889a394.js"
  },
  {
    "revision": "a86892b4ea3ef0e0f3d6bbb46ea28639",
    "url": "./static/media/power-off-solid.a86892b4.svg"
  },
  {
    "revision": "4827aa5676407ca55b9f9acb062db4de",
    "url": "./static/media/spinner-solid.4827aa56.svg"
  },
  {
    "revision": "83edbac2a77576c81c729ae3d32f8699",
    "url": "./static/media/tools-solid.83edbac2.svg"
  },
  {
    "revision": "c198e9b9db90c27ceca2ea983044d572",
    "url": "./static/media/undo-alt-solid.c198e9b9.svg"
  }
]);